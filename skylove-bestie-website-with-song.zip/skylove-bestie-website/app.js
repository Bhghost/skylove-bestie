const $ = (s) => document.querySelector(s);
const loader = $("#loader");
window.addEventListener("load", () => setTimeout(() => loader.classList.add("hide"), 1250));

const ambient = $("#ambient");
for (let i=0;i<24;i++){const star=document.createElement("i");star.textContent=["✦","♡","✧","·"][i%4];star.style.left=Math.random()*100+"%";star.style.animationDuration=(12+Math.random()*18)+"s";star.style.animationDelay=(-Math.random()*20)+"s";star.style.fontSize=(10+Math.random()*17)+"px";ambient.append(star);}

const nav=$("#nav"), menuToggle=$("#menuToggle");
menuToggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuToggle.setAttribute("aria-expanded",String(open));menuToggle.textContent=open?"×":"☰";});
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");menuToggle.textContent="☰";}));
const sections=[...document.querySelectorAll("main section[id]")];
window.addEventListener("scroll",()=>{let current="home";sections.forEach(s=>{if(scrollY>=s.offsetTop-150)current=s.id;});nav.querySelectorAll("a").forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+current));});

const modal=$("#modal");
function showModal(title,message){$("#modalTitle").textContent=title;$("#modalText").textContent=message;modal.hidden=false;$("#modalOkay").focus();}
function closeModal(){modal.hidden=true;}
$("#modalClose").addEventListener("click",closeModal);$("#modalOkay").addEventListener("click",closeModal);
modal.addEventListener("click",e=>{if(e.target===modal)closeModal();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
const surpriseText=[
["A truth about you","You make people feel seen. That is a rare and beautiful gift. Never let the world make you forget it."],
["Your little reminder","You deserve gentle love, loud laughter, peaceful days, and every good thing your heart has been wishing for."],
["A promise from your bestie","Even when life gets busy, I hope you always remember that you have someone cheering for you from your corner."],
["Your crown moment 👑","You are one of one, Skylove. No comparison, no competition — just your own beautiful kind of magic."]
];
function gift(){const item=surpriseText[Math.floor(Math.random()*surpriseText.length)];showModal(item[0],item[1]);}
$("#openGift").addEventListener("click",gift);$("#heroSurprise").addEventListener("click",gift);

const truths=["What is one memory that always makes you smile?","What is one dream you really want to achieve?","What was your first impression of your bestie?","What small thing can instantly make your day better?"];
const dares=["Send someone a genuine compliment today.","Take a selfie with your biggest smile.","Say three things you love about yourself.","Dance to your favourite song for 20 seconds."];
$("#truthDare").addEventListener("click",()=>{const isTruth=Math.random()>.5;const list=isTruth?truths:dares;$("#truthResult").textContent=(isTruth?"TRUTH: ":"DARE: ")+list[Math.floor(Math.random()*list.length)];});
const quiz=["What is the strongest ingredient in a lasting friendship?","What should a bestie never run out of?","What makes this bond special?"];
const answers=[["Trust and kindness","Matching shoes","Being online 24/7"],["Laughter and support","Drama","Unread messages"],["Being there for each other","Perfect selfies","Agreeing on everything"]];
let qi=0;
$("#quizBtn").addEventListener("click",()=>{const result=$("#quizResult");if(qi>=quiz.length)qi=0;const n=qi++;result.textContent=quiz[n]+" — My answer: "+answers[n][0]+". (Your turn: what would you choose?)";if(qi===quiz.length)$("#quizBtn").textContent="Play again ♡";});
const compliments=["Your smile deserves its own sunrise.","You are a beautiful soul with a golden heart.","You make ordinary moments feel special.","You are worthy of every good thing coming your way.","Never shrink your light to make the world comfortable."];
$("#complimentBtn").addEventListener("click",()=>{$("#complimentResult").textContent=compliments[Math.floor(Math.random()*compliments.length)];});

const form=$("#messageForm"), wall=$("#messageWall"), STORAGE="skylove-bestie-messages-v1";
function safe(text){return String(text).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderMessages(){let items=[];try{items=JSON.parse(localStorage.getItem(STORAGE)||"[]");}catch{}wall.innerHTML=items.slice(0,9).map(x=>`<article class="message-note"><strong>${safe(x.sender)} ♡</strong><p>${safe(x.message)}</p></article>`).join("");}
form.addEventListener("submit",e=>{e.preventDefault();const sender=$("#sender").value.trim(),message=$("#message").value.trim();if(!sender||!message)return;let items=[];try{items=JSON.parse(localStorage.getItem(STORAGE)||"[]");}catch{}items.unshift({sender,message});try{localStorage.setItem(STORAGE,JSON.stringify(items.slice(0,30)));renderMessages();form.reset();$("#formHint").textContent="Your message has been added to this browser's love wall. ♡";}catch{$("#formHint").textContent="This browser could not save the message. Try another browser.";}});renderMessages();

const song=$("#bestieSong");
const musicBtn=$("#musicBtn");
const musicLabel=$("#musicLabel");

function setMusicState(playing){
  musicBtn.setAttribute("aria-pressed",String(playing));
  musicLabel.textContent=playing?"Pause our song":"Tap to play our song";
}
async function startSong(){
  try{
    await song.play();
    setMusicState(true);
  }catch(error){
    // Browsers commonly block audible autoplay until the visitor interacts.
    setMusicState(false);
  }
}
function toggleSong(){
  if(song.paused){
    startSong();
  }else{
    song.pause();
    setMusicState(false);
  }
}
musicBtn.addEventListener("click",toggleSong);
song.addEventListener("play",()=>setMusicState(true));
song.addEventListener("pause",()=>setMusicState(false));
window.addEventListener("load",()=>{ startSong(); },{once:true});
