# Skylove — Besties Forever

A responsive, single-page best-friend tribute website.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a browser, or use VS Code Live Server.
3. No build tools or server are required.

## Features
- Animated loading screen and floating sparkles
- Responsive navigation for phones, tablets and desktop
- Original anime-inspired male/female bestie illustration (`assets/besties.svg`)
- Friendship story, 100% bond meter, gallery and love letter
- Truth-or-dare, mini bestie quiz and compliment machine
- Surprise gift modal
- Message wall saved in the current browser using localStorage
- Original synthesized melody

## Music note
The supplied `assets/headlights.mp3` track is embedded and the page attempts to autoplay it on load. Most modern browsers block audible autoplay until the visitor interacts with the page. If autoplay is blocked, tap **Our song** in the top navigation to start it. The track loops.

## Personalising
- Edit the wording in `index.html`.
- Replace `assets/besties.svg` with your own image and update the image paths in `index.html`.
- Messages are stored only on the same browser/device. To share messages across devices, connect a database such as Firebase.
